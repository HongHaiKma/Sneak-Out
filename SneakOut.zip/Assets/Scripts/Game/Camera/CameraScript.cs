using PFramework;

namespace Game
{
    public class CameraScript : Singleton<CameraScript>
    {
    }
}