﻿namespace PFramework
{
    public enum PProduct
    {
    }
}