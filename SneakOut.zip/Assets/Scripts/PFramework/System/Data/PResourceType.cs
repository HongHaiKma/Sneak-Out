﻿namespace PFramework
{
    [System.Serializable]
    public enum PResourceType
    {
        Coin = 0,
        Gem = 1,
        Energy = 2,
    }
}